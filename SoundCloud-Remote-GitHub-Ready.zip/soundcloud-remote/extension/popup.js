document.querySelector('#connect').onclick = async () => {
  const status = document.querySelector('#status');
  status.textContent = 'Connecting…';
  try {
    const result = await chrome.runtime.sendMessage({action: 'connect'});
    status.textContent = result.ok ? 'Connected. You can now pair your Android phone.' : result.error;
  } catch (_) { status.textContent = 'Connection failed. Restart the PC helper and reload SoundCloud.'; }
};
