# SoundCloud Wi-Fi Remote

An unofficial Android remote for SoundCloud playing in Chrome or Edge on a Windows PC.

![Remote interface](Preview.png)

## Setup

1. Download this repository as a ZIP and extract it.
2. Run **Start-PC.bat** on Windows. It uses existing Python 3.10+ or downloads and verifies the official portable runtime.
3. Open `chrome://extensions` or `edge://extensions`, enable Developer mode, choose **Load unpacked**, and select `extension`.
4. Open or refresh SoundCloud, start a track, then click the extension and **Connect SoundCloud tab**.
5. Install [SoundCloud-Remote.apk](SoundCloud-Remote.apk) on Android 9 or newer.
6. Connect both devices to the same trusted home network and enter the address and pairing code from the PC helper.

Keep the helper and SoundCloud tab open. See [START-HERE.txt](START-HERE.txt) for troubleshooting.

## Features

Playback, previous/next, seeking, SoundCloud player volume, mute, shuffle, repeat, likes, and a PC-side sleep timer. Search and library shortcuts open in the PC browser. The waveform is a stylized progress display.

## Architecture

The Android app packages a local HTML/CSS/JavaScript interface in a WebView. Its native bridge sends authenticated HTTP requests to the Python LAN relay. A Manifest V3 browser extension exchanges playback state and commands with that relay and operates SoundCloud's visible player controls.

No SoundCloud password is collected. Local traffic uses HTTP and is intended for trusted home networks; do not expose the helper port to the internet. Album artwork can load directly from SoundCloud.

## Build and validation

Android SDK platform 35, build-tools 35.0.0, and JDK 17 are required. Set `ANDROID_JAR` and `BUILD_TOOLS`, then run `bash android/build.sh`. The script creates a development signing key locally; signing keys are excluded from this repository. A locally rebuilt APK uses a different key from the supplied APK, so switching builds may require uninstalling the existing app and pairing again.

Run relay tests with `python tests/test_relay.py`. UI tests require Playwright and a Chromium executable supplied through `CHROME_BIN`: `node tests/test_ui.cjs`.

The APK build, relay integration tests and simulated UI/adapter tests passed. Physical Android/Windows installation and live end-to-end playback have not been verified. SoundCloud site changes may require updating the adapter. See [TEST-RESULTS.txt](TEST-RESULTS.txt).

This project is not affiliated with SoundCloud.
